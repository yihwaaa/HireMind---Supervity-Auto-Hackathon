# app/routers/supervity.py
"""
Proxy endpoints for the Supervity Auto integration.

The Next.js frontend never calls Supervity directly — it calls this backend,
which holds the API key server-side (see app/services/supervity.py) and
forwards the request. This matches Supervity's own guidance: proxy workflow
endpoints through your backend rather than exposing a JWT/API key to the
browser.

Wire the Command Center to these routes:
  - Dashboard "Escalate ..." action buttons -> POST /supervity/workflows/{id}/run
  - AI Manager "trigger the Orchestrator" -> POST /supervity/workflows/{id}/run/stream
  - Data Manager "Supervity Auto" row health -> GET /supervity/workflows
  - Workbench audit trail -> GET /supervity/workflow-runs/{run_id}
"""

import logging

import httpx
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from ..services.supervity import (
    SUPERVITY_ORCHESTRATOR_WORKFLOW_ID,
    SupervityAPIError,
    SupervityConfigError,
    supervity,
)

log = logging.getLogger(__name__)

router = APIRouter(prefix="/supervity", tags=["Supervity Auto"])


@router.get("/status")
async def connection_status():
    """
    Real health check for the Data Manager — hits Supervity, doesn't guess.
    Returns connected=True only if GET /workflows/{orchestrator_id} actually
    succeeded against your configured SUPERVITY_ORCHESTRATOR_WORKFLOW_ID.
    """
    return await supervity.check_orchestrator_connection()


@router.post("/orchestrator/run")
async def run_orchestrator(body: dict):
    """
    Same as POST /workflows/{id}/run, but uses SUPERVITY_ORCHESTRATOR_WORKFLOW_ID
    from .env so callers (Dashboard buttons, Workbench, AI Manager) never
    need to know or pass the raw workflow ID.

    Body: {"inputs": {...}, "envs": {...}}
    """
    if not SUPERVITY_ORCHESTRATOR_WORKFLOW_ID:
        raise HTTPException(
            status_code=503,
            detail="SUPERVITY_ORCHESTRATOR_WORKFLOW_ID is not set in .env",
        )
    try:
        return await supervity.execute_workflow(
            SUPERVITY_ORCHESTRATOR_WORKFLOW_ID,
            inputs=body.get("inputs"),
            envs=body.get("envs"),
        )
    except Exception as exc:
        _handle(exc)


def _handle(exc: Exception):
    if isinstance(exc, SupervityConfigError):
        raise HTTPException(status_code=503, detail=str(exc))
    if isinstance(exc, SupervityAPIError):
        raise HTTPException(status_code=exc.status_code, detail=exc.detail)
    if isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout)):
        log.exception("Could not reach auto.supervity.ai")
        raise HTTPException(
            status_code=502,
            detail=(
                "Could not reach auto.supervity.ai from the backend container. "
                "Check the container has outbound internet access and that "
                "SUPERVITY_BASE_URL is correct."
            ),
        )
    log.exception("Unexpected Supervity integration error")
    raise HTTPException(status_code=502, detail="Supervity Auto request failed")


@router.get("/workflows")
async def list_workflows(page: int = 1, limit: int = 20, search: str | None = None):
    """List workflows visible to this org — use this to find your Orchestrator's ID."""
    try:
        return await supervity.list_workflows(page=page, limit=limit, search=search)
    except Exception as exc:
        _handle(exc)


@router.get("/workflows/{workflow_id}")
async def get_workflow(workflow_id: str):
    try:
        return await supervity.get_workflow(workflow_id)
    except Exception as exc:
        _handle(exc)


@router.post("/workflows/{workflow_id}/run")
async def run_workflow(workflow_id: str, body: dict):
    """
    Kicks off the run. Supervity queues it and returns immediately —
    {"accepted": true, "message": "Execution started"} — it does NOT wait
    for the Orchestrator to finish. Follow up with GET /workflow-runs
    (filtered by this workflow_id) to find the run, then poll
    GET /workflow-runs/{run_id} for status/outputs. For live progress
    instead of polling, use the /run/stream endpoint below.

    Body: {"inputs": {...}, "envs": {...}}
    """
    try:
        result = await supervity.execute_workflow(
            workflow_id,
            inputs=body.get("inputs"),
            envs=body.get("envs"),
        )
        # TODO: persist this run to the audit log / DB here so the
        # dashboard, Insights, and Workbench have real history — see
        # app/services/audit.py for the existing logging middleware.
        return result
    except Exception as exc:
        _handle(exc)


@router.post("/workflows/{workflow_id}/run/stream")
async def run_workflow_stream(workflow_id: str, body: dict):
    """
    Streaming execution (SSE) — forwards live progress as the Orchestrator
    delegates to its Operators, so the AI Manager / Workbench UI can show
    it happening in real time instead of a blank spinner.
    """
    try:
        return StreamingResponse(
            supervity.stream_workflow(
                workflow_id,
                inputs=body.get("inputs"),
                envs=body.get("envs"),
            ),
            media_type="text/event-stream",
        )
    except Exception as exc:
        _handle(exc)


@router.get("/workflow-runs")
async def list_workflow_runs(
    workflow_id: str | None = None,
    status: str | None = None,
    page: int = 1,
    limit: int = 10,
):
    try:
        return await supervity.list_workflow_runs(
            workflow_id=workflow_id, status=status, page=page, limit=limit
        )
    except Exception as exc:
        _handle(exc)


@router.get("/workflow-runs/{run_id}")
async def get_workflow_run(run_id: str):
    try:
        return await supervity.get_workflow_run(run_id)
    except Exception as exc:
        _handle(exc)


@router.get("/workflow-runs/dashboard/{workflow_id}")
async def get_dashboard_stats(workflow_id: str):
    """Run-count breakdown by status — feed straight into a KpiGrid card."""
    try:
        return await supervity.get_dashboard_stats(workflow_id)
    except Exception as exc:
        _handle(exc)
