'use client'

import { DataTable, type DataTableColumn } from '@/components/ui/data-table'
import { StatusPill } from '@/components/ui/status-pill'
import { Icons } from '@/components/ui/icons'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

type ConnectionStatus = 'Healthy' | 'Degraded' | 'Not Connected'
type SystemCategory = 'System of Record' | 'Channel' | 'Orchestration' | 'Database'

interface ConnectedSystem {
  id: string
  name: string
  category: SystemCategory
  usedFor: string
  status: ConnectionStatus
  lastSynced: string
}

// This registry reflects real connection state — update it as each
// integration is actually wired up. Do not mark something "Healthy"
// until the backend has verified the connection.
const SYSTEMS: ConnectedSystem[] = [
  {
    id: '1',
    name: 'PostgreSQL (Backend DB)',
    category: 'Database',
    usedFor: 'Persists workflow runs, policy evaluations, audit log, and exception history',
    status: 'Healthy',
    lastSynced: 'Live',
  },
  {
    id: '2',
    name: 'Supervity Auto (Orchestrator)',
    category: 'Orchestration',
    usedFor: 'Runs the Orchestrator and its 5+ Operator Agents for onboarding & retention',
    status: 'Not Connected',
    lastSynced: '—',
  },
  {
    id: '3',
    name: 'Airtable / SharePoint',
    category: 'System of Record',
    usedFor: 'Worker register, onboarding tasks, compliance items, payroll records',
    status: 'Not Connected',
    lastSynced: '—',
  },
  {
    id: '4',
    name: 'Slack',
    category: 'Channel',
    usedFor: 'Manager nudges and at-risk-hire escalation notifications',
    status: 'Not Connected',
    lastSynced: '—',
  },
  {
    id: '5',
    name: 'Outlook',
    category: 'Channel',
    usedFor: 'Compliance deadline reminders and first-payroll exception alerts',
    status: 'Not Connected',
    lastSynced: '—',
  },
]

const statusTone = {
  Healthy: 'success',
  Degraded: 'high',
  'Not Connected': 'neutral',
} as const

const categoryTone = {
  'System of Record': 'medium',
  Channel: 'medium',
  Orchestration: 'medium',
  Database: 'medium',
} as const

const COLUMNS: DataTableColumn<ConnectedSystem>[] = [
  {
    key: 'name',
    header: 'System',
    render: (r) => <span className='font-medium text-brand-navy'>{r.name}</span>,
  },
  {
    key: 'category',
    header: 'Category',
    render: (r) => <StatusPill tone={categoryTone[r.category]}>{r.category}</StatusPill>,
  },
  { key: 'usedFor', header: 'Used For', render: (r) => <span className='text-brand-muted'>{r.usedFor}</span> },
  {
    key: 'status',
    header: 'Connection Status',
    render: (r) => <StatusPill tone={statusTone[r.status]}>{r.status}</StatusPill>,
  },
  { key: 'lastSynced', header: 'Last Synced', render: (r) => r.lastSynced },
]

const healthyCount = SYSTEMS.filter((s) => s.status === 'Healthy').length
const channelCount = SYSTEMS.filter((s) => s.category === 'Channel').length
const sorCount = SYSTEMS.filter((s) => s.category === 'System of Record').length

export default function DataManagerPage() {
  return (
    <div className='space-y-6'>
      <div>
        <h1 className='font-display text-2xl font-bold tracking-tight text-brand-navy lg:text-3xl'>
          Data Manager
        </h1>
        <p className='mt-1 text-sm text-brand-muted'>
          Live registry of every system this operation connects to, what it&apos;s used for,
          and whether the connection is healthy.
        </p>
      </div>

      <div className='grid grid-cols-2 gap-4 lg:grid-cols-4'>
        <Card>
          <CardContent className='p-4'>
            <p className='text-xs font-medium uppercase tracking-wide text-brand-muted'>Connected</p>
            <p className='mt-2 font-display text-2xl font-bold text-brand-navy'>
              {healthyCount} / {SYSTEMS.length}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className='p-4'>
            <p className='text-xs font-medium uppercase tracking-wide text-brand-muted'>Channels</p>
            <p className='mt-2 font-display text-2xl font-bold text-brand-navy'>{channelCount}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className='p-4'>
            <p className='text-xs font-medium uppercase tracking-wide text-brand-muted'>Systems of Record</p>
            <p className='mt-2 font-display text-2xl font-bold text-brand-navy'>{sorCount}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className='p-4'>
            <p className='text-xs font-medium uppercase tracking-wide text-brand-muted'>Required for Gate</p>
            <p className='mt-2 font-display text-2xl font-bold text-brand-navy'>3 (2+ categories)</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className='flex flex-row items-center justify-between space-y-0'>
          <CardTitle className='flex items-center gap-2 text-base'>
            <Icons.database className='h-4.5 w-4.5 text-brand-cornflower' strokeWidth={1.75} />
            Connected Systems
          </CardTitle>
          <span className='text-micro uppercase text-brand-muted'>{SYSTEMS.length} registered</span>
        </CardHeader>
        <CardContent className='p-0'>
          <DataTable columns={COLUMNS} rows={SYSTEMS} getRowId={(r) => r.id} />
        </CardContent>
      </Card>

      <Card className='border-amber-200 bg-amber-50/40'>
        <CardContent className='flex items-start gap-3 p-4'>
          <Icons.alertTriangle className='mt-0.5 h-4.5 w-4.5 shrink-0 text-amber-600' strokeWidth={1.75} />
          <div>
            <p className='text-sm font-medium text-brand-navy'>Wire this up before the freeze</p>
            <p className='mt-0.5 text-sm text-brand-muted'>
              This registry is honest about current state — most systems above are not yet
              connected. Judges check the Data Manager against what&apos;s actually live, so
              update each row&apos;s status only once the backend has verified that connection
              (see <code className='rounded bg-white px-1 py-0.5 text-xs'>app/services/supervity.py</code>{' '}
              for the Auto Orchestrator connection).
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
